import React from "react";
import Vehicle from "../Assets/motor-icon.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCircleCheck,
  faCalendarCheck,
} from "@fortawesome/free-solid-svg-icons";
import { useNavigate  } from "react-router-dom";
import "../Styles/BookAppointment.css";

function BookAppointment() {
  const navigate = useNavigate();

  const handleBookAppointmentClick = () => {
    navigate("/appointment");
  };

  return (
    <div className="ba-section">
      <div className="ba-image-content">
        <img src={Vehicle} alt="Insurance Policy " className="ba-image1" />
      </div>

      <div className="ba-text-content">
        <h3 className="ba-title">
          <span>Vehicle Insurance</span>
        </h3>
        <p className="ba-description">
        Vehicle insurance provides financial protection against accidents, theft, and damage to your vehicle. It ensures peace of mind by covering repair costs and liability expenses in case of accidents. Moreover, it's often a legal requirement, ensuring compliance with regulations while safeguarding your investment and mitigating unforeseen financial burdens.
        </p>

        <button
          className="text-appointment-btn"
          type="button"
          onClick={handleBookAppointmentClick}
        >
          <FontAwesomeIcon icon={faCalendarCheck} /> Buy an Vehicle Insurance 
        </button>
      </div>
    </div>
  );
}

export default BookAppointment;
